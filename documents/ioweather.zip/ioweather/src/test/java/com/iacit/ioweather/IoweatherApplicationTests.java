package com.iacit.ioweather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IoweatherApplicationTests {

	@Test
	void contextLoads() {
	}

}
